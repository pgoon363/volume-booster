package com.example.volumebooster

import android.media.audiofx.LoudnessEnhancer
import android.os.Bundle
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    // LoudnessEnhancer attached to audio session 0 = the phone's global audio output.
    private var enhancer: LoudnessEnhancer? = null

    // Boost amount in millibels (mB). 100 mB = 1 dB. Max here is 2000 mB = +20 dB.
    private var gainMb = 0

    private lateinit var boostSwitch: SwitchMaterial
    private lateinit var seekBar: SeekBar
    private lateinit var gainLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        boostSwitch = findViewById(R.id.boostSwitch)
        seekBar = findViewById(R.id.seekBar)
        gainLabel = findViewById(R.id.gainLabel)

        seekBar.max = 2000
        updateLabel()

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                gainMb = progress
                updateLabel()
                if (boostSwitch.isChecked) applyGain()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        boostSwitch.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) enableBoost() else disableBoost()
        }
    }

    private fun updateLabel() {
        val db = gainMb / 100.0
        gainLabel.text = "Boost: +%.1f dB".format(db)
    }

    private fun enableBoost() {
        try {
            if (enhancer == null) {
                enhancer = LoudnessEnhancer(0)
            }
            applyGain()
            enhancer?.enabled = true
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start booster: ${e.message}", Toast.LENGTH_LONG).show()
            boostSwitch.isChecked = false
        }
    }

    private fun applyGain() {
        try {
            enhancer?.setTargetGain(gainMb)
        } catch (e: Exception) {
            Toast.makeText(this, "Error applying boost: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun disableBoost() {
        enhancer?.enabled = false
    }

    override fun onDestroy() {
        super.onDestroy()
        enhancer?.release()
        enhancer = null
    }
}

# Volume Booster (Android)

A simple volume booster app. It uses Android's built-in `LoudnessEnhancer`
to raise the overall loudness of your phone's audio output, with a slider
(0 to +20 dB) and an on/off switch.

## How to turn this into an installable app

You have two routes. Route A needs ONLY your phone. Route B needs a computer.

---

### ROUTE A — Build in the cloud with GitHub (phone only, free)

1. Create a free account at https://github.com
2. Click the "+" (top right) → "New repository".
   - Name it: volume-booster
   - Keep it Public (free Actions minutes) → "Create repository".
3. On the new repo page, click "uploading an existing file".
4. Unzip VolumeBooster.zip on your phone (any file manager / ZIP app),
   then upload ALL the files and folders, keeping the folder structure.
   (On phone this is easiest with the GitHub mobile app, or upload folder
   by folder in the browser. The hidden ".github" folder must be included.)
5. Commit the files (green "Commit changes" button).
6. Go to the "Actions" tab of your repo. A workflow called "Build APK"
   will run automatically (takes 2–5 minutes). Wait for the green tick.
7. Click the finished run → scroll to "Artifacts" → download
   "volume-booster-apk". It downloads a .zip; unzip it to get
   app-debug.apk.
8. Install app-debug.apk on your phone (see "Installing on your Vivo" below).

---

### ROUTE B — Build on a computer with Android Studio (free)

1. Download Android Studio: https://developer.android.com/studio
2. Install it (accept the default SDK components when asked).
3. Open Android Studio → "Open" → select the unzipped VolumeBooster folder.
4. Wait for it to finish "Gradle sync" (first time downloads components).
5. Menu: Build → Build App Bundle(s) / APK(s) → Build APK(s).
6. When done, click "locate" in the popup. The file is:
   app/build/outputs/apk/debug/app-debug.apk
7. Copy that APK to your phone and install it (see below).

---

## Installing the APK on your Vivo T4X

1. Copy app-debug.apk to your phone (if it isn't already there).
2. Open your Files app and tap the APK.
3. Android will warn about installing from an unknown source. Tap
   "Settings" → allow "Install unknown apps" for the app you're using
   (Files, Chrome, etc.) → go back and tap Install.
4. On Vivo (Funtouch OS), you may also see a security scan prompt — tap
   "Install anyway". You may need to toggle OFF "External source auto
   scan" or "Verify apps" in Settings > Security if it blocks you.
5. Open "Volume Booster" from your app drawer.

## How to use it

- Turn your phone's media volume to maximum first.
- Open the app, drag the slider up, and flip "Enable boost" on.
- Play music/video and adjust the slider to taste.

## Important notes

- This is a "debug" APK (unsigned for the store). It installs fine for
  personal use but is not meant for publishing to Google Play.
- Some phone makers (Vivo included) limit how much extra gain the system
  allows, so the real-world boost may be smaller than +20 dB.
- Loud boost can damage your hearing and your speaker. Increase slowly.
